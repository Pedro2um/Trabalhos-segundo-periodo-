time clear
time make
time ./exec 
